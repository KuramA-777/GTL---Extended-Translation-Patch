Github repo with more information: 
https://github.com/BirbIrl/ComputerCraft-Greg-Flavored?tab=readme-ov-file

